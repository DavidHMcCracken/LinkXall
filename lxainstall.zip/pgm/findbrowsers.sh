#!/bin/bash
# findbrowsers.sh
# Update 2025.04.27
# Use: findBrowsers.sh resultfile (see LXAIsearchBrowser) 
#
# This is a "smart" program for LXAIshellExe, initially writing a blank result 
# file to indicate that it has started and making that RO when done.
# ............................................................
echo -n > "$1"
which firefox > "$1"
which chromium >> "$1"
which edge >> "$1"
which opera >> "$1"
chmod 444 "$1"
