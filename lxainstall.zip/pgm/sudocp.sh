#!/bin/bash
# sudocp.sh
# Update 2025.04.27
# Use: sudocp.sh srcfile desdir optional resultfile
# If desdir is not owned by root then simply copy srcfile into it. Otherwise
# do sudo copy. This is intended to support LibreOffice macros. FileCopy and
# shell programs can't do sudo because they don't provide a means for user to
# enter password. That is provided here by invoking xterm. Both grep and xterm
# are required. 
#
# This is a "smart" program for LXAIshellExe, initially writing a blank result 
# file to indicate that it has started and making that RO when done, whether or 
# not anything more has been written. 
# .........................................................................
if test "$3" != "" ; then echo -n > "$3" ; fi
if ls -ld "$2" | grep root ; then
    xterm -e sudo cp "$1" "$2"
else
    cp "$1" "$2"
fi
if test "$3" != "" ; then chmod 444 "$3" ; fi
