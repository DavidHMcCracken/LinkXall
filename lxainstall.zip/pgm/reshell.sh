#!/bin/bash
# reshell.sh
# Updated 2025.04.26.10.12
# Linux lxainstall helper. Reboot the shell to register environment variable
# changes. If this does not work, try restart lightdm or whatever 
# cat /etc/X11/default-display-manager says.
# ..........................................................................
xterm -e "read -p 'Close all Libre windows and then press Enter to reboot the shell' -n 5 junk ; sudo systemctl restart display-manager"
