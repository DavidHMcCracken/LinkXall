#!/bin/bash
# findemacs.sh
# Update: 2025.04.27
#
# This is a "smart" program for LXAIshellExe, initially writing a blank result 
# file to indicate that it has started and making that RO when done.
# ............................................................
echo -n > "$1"
whereis -b emacs > "$1"
which emacs >> "$1"
chmod 444 "$1"
