#!/bin/bash
# linx.sh
# Updated: 2025.04.22.20.35
# Execute a shell command in Linux for Libre-Basic, whose shell command does not
# properly invoke shell commands with wildcards in arguments.
# ........................................................................
$1
# echo "$1" > /home/d/work/swdev/libre/lxainstall/cmdcheck
