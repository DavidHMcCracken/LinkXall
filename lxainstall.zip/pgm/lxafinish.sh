#!/bin/bash
# lxafinish.sh
# Updated 2025.04.27
# lxainstall helper. Install, remove, and some configuration operations require
# Libre to close and then its working files replaced. This script provides the 
# framework for that. The LXAIfinish macro copies it from pgm to tmp, where it 
# adds the specific operations and then invokes it. User interaction is 
# required but, in Linux, Libre doesn't open a terminal window for scripts. 
# xterm is invoked here to provide that. The interactive commands are passed as 
# one argument for xterm to execute. First the user is instructed to close 
# Libre windows. Then killall is invoked to wait (-w) for the user to do this 
# or force Libre to close in case the user neglected to close all windows. A 
# final request for input keeps the terminal window open for the user to see 
# any error messages and to ensure a stable file system for the subsequent file 
# copy operations (added to this script). The terminal window closes on this 
# final user input.
# ..........................................................................
xterm -e "read -p 'Close all Libre windows and then press Enter to continue' -n 5 junk ; killall -1 -q -w soffice.bin ; read -p 'Press Enter to finish...' -n 5 junk"
