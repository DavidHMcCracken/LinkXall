#!/bin/bash
# File: inpath.sh
# Updated: 2025.04.27
# Use: inpath.sh resultfile pgm1 pgm2 ... (see LXAIwherePgm)
# Determine the PATH directory of one or more given programs. The filespec of 
# each one in PATH is written to the result file. A line containing only "-" is 
# written for those that are not in PATH. See LxaInstaller.odt LXAIwherePgm.
#
# This is a "smart" program for LXAIshellExe, initially writing a blank result 
# file to indicate that it has started and making that RO when done.
# ........................................................................
resfile="$1"
echo -n > "$1"
shift
for pgm
do
    which "$pgm" >> "$resfile"
    if [ $? -ne 0 ] ; then echo "-" >> "$resfile" ; fi
done
chmod 444 "$resfile"
