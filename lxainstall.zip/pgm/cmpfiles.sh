#!/bin/bash
# File: cmpfiles.sh
# Update 2025.04.22.21.24
# Use: cmpfiles.sh file1 file2 resultfile
# Result: 0 = equal, 1 = different, 2 = one or both missing.
# This is a "smart" program for LXAIshellExe, initially writing a blank result 
# file to indicate that it has started and making that RO when done.
# see LXAIcmpFiles and LXAIshellExe in LxaInstall.odt.Standard
# ............................................................
echo -n > "$3"
cmp "$1" "$2" &> /dev/null 
echo "$?" > "$3"
chmod 444 "$3"
