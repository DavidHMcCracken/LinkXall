This is a Win32 console application. dsp and dsw files are project and workspace
definitions for building in Microsoft Visual C++ 6.0. vcxproj and sln files are 
for Visual Studio 2017. Any newer version of Visual Studio can "migrate" these
but not the dsp and dsw files. The only required library is user32.lib but VC6
includes a lot of other library information even in the release build, making
its executable much larger than the one produced by VS2017. However, execution
speed is the same for both.

