#!/usr/bin/env python3
# tip.py Updated 2025.05.02.11.58
# Copy LinkXall library, config.txt, and envar.txt to named directory or here.
# --------------------------------------------------------------
import os, sys, shutil

if len(sys.argv) < 2 : 
    des = os.getcwd()
else :
    des = sys.argv[1]
    if os.path.exists(des) :
        if input('Do you want to overwrite %s?[y/n] '%des).upper() != 'Y' : exit()
        if input('Do you want to delete its current files?[y/n] ').upper() == 'Y' :
            for f in os.listdir(des) :
                os.remove(des + '/' + f)
    else :
        os.makedirs(des)

if sys.platform.lower()[0:3] == 'win' :
    libdir = '%s\\LibreOffice\\4\\user\\basic\\LinkXall'%os.getenv('APPDATA')
    datdir = '%s\\LibreOffice\\4\\user\\LinkXall'%os.getenv('APPDATA')
else :
    libdir = '%s/.config/libreoffice/4/user/basic/LinkXall'%os.getenv('HOME')
    datdir = '%s/.config/libreoffice/4/user/LinkXall'%os.getenv('HOME')

print('Copy library from %s'%libdir)
for f in os.listdir(libdir) : shutil.copy2('%s/%s'%(libdir,f),des)

print('Copy config.txt from %s'%datdir)
shutil.copy2('%s/config.txt'%datdir, des)
lxaenv = os.getenv('LINKXALL_ENV')
if lxaenv == None or not os.path.exists('%s/envar.txt'%lxaenv) :
    if os.path.exists('%s/envar.txt'%datdir) :
        lxaenv = datdir
    else :
        print('envar.txt is not in %s or %s'%(lxaenv,datdir))
if lxaenv != None :
    print('Copy envar.txt from %s'%lxaenv)
    shutil.copy2('%s/envar.txt'%lxaenv, des)
