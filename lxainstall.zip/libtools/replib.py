#!/usr/bin/env python3
# replib.py  Updated: 2025.05.02.11.59
# Replace the working LinkXall library with a repository version.
# --------------------------------------------------------------
import os, sys

if len(sys.argv) < 2 :
    ver = 'lib+'
else :
    ver = sys.argv[1]
if input('Do you want to replace the library with version %s?[y/n] '%ver).upper() != 'Y' :
    exit()

if sys.platform.lower()[0:3] == 'win' :
    libdir = '%s\\LibreOffice\\4\\user\\basic\\LinkXall'%os.getenv('APPDATA')
else :
    libdir = '%s/.config/libreoffice/4/user/basic/LinkXall'%os.getenv('HOME')

os.system('dv.py %s -get %s'%(ver, libdir))
