#!/usr/bin/env python3
# putdoc.py Updated 2025.05.23.09.53
# Invoke dv.py to put LxaUserGuide and LxaDesign to bak/doc+
# ---------------------------------------------------------
import os
os.system("dv.py doc+ LxaUserGuide.odt LxaDesign.odt LxaTut.odt")
