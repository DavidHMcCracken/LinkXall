#!/usr/bin/env python3
# put.py Updated: 2025.05.22.09.33
# Combine putlib.py, putdoc.py, puttest.py, and puttools.py for overall linkxall
# workspace version capture, library to lib+, LinkXall docs to doc+, odt test
# files to test+, and scripts to tools+. dv.py will warn about any group that
# is unchanged from the most recent version. putcfg.py is not included because
# its config.txt is constantly changing and routinely capturing it would serve
# no purpose.
# --------------------------------------------------------------
import os, sys

# Put library. This is similar to putlib.py but unconditionally puts to lib+
# while putlib.py accepts a version name command argument.
ver = 'lib+'
cwd = os.getcwd()
if sys.platform.lower()[0:3] == 'win' :
    libdir = '%s\\LibreOffice\\4\\user\\basic\\LinkXall'%os.getenv('APPDATA')
else :
    libdir = '%s/.config/libreoffice/4/user/basic/LinkXall'%os.getenv('HOME')
os.chdir(libdir)
os.system('dv.py %s *'%os.path.normpath('%s/bak/%s'%(cwd,ver)))
os.chdir(cwd)

# Put LinkXall documentation to doc+
os.system("dv.py doc+ LxaUserGuide.odt LxaDesign.odt LxaTut.odt")

# Put test docs (all odt except LinkXall documentation) to test+
os.system("dv.py test+ -[LxaUserGuide.odt,LxaDesign.odt,LxaTut.odt] .odt")

# Put scripts and help to tools+
os.system("dv.py tools+ .py .bat .sh help")
