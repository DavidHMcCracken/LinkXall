#!/usr/bin/env python3
# puttest.py Updated 2025.05.22.09.54
# Invoke dv.py to put all odt files except LxaUserGuide and LxaDesign to 
# bak/test+
# --------------------------------------------------------------
import os
os.system("dv.py test+ -[LxaUserGuide.odt,LxaDesign.odt,LxaTut.odt] .odt")
