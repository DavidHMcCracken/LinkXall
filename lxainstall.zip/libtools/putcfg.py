#!/usr/bin/env python3
# putcfg.py Updated: 2025.05.02.12.00
# Copy LinkXall config.txt and envar.txt to CWD (library workspace) and  put to 
# bak/cfg+
# --------------------------------------------------------------
import os, sys, shutil

cwd = os.getcwd()

if sys.platform.lower()[0:3] == 'win' :
    datdir = '%s\\LibreOffice\\4\\user\\LinkXall'%os.getenv('APPDATA')
else :
    datdir = '%s/.config/libreoffice/4/user/LinkXall'%os.getenv('HOME')

print('Get config.txt from %s'%datdir)
shutil.copy2('%s/config.txt'%datdir, cwd)

lxaenv = os.getenv('LINKXALL_ENV')
if lxaenv == None or not os.path.exists('%s/envar.txt'%lxaenv) :
    if os.path.exists('%s/envar.txt'%datdir) :
        lxaenv = datdir
    else :
        print('envar.txt is not in %s or %s'%(lxaenv,datdir))
if lxaenv != None :
    print('Get envar.txt from %s'%lxaenv)
    shutil.copy2('%s/envar.txt'%lxaenv, cwd)

os.system('dv.py cfg+ config.txt envar.txt')
