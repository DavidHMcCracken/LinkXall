#!/usr/bin/env python3
# putlib.py Updated: 2025.05.02.12.04
# Invoke dv.py to put the working LinkXall library to bak/lib+
# --------------------------------------------------------------
import os, sys

if len(sys.argv) < 2 :
    ver = 'lib+'
else :
    ver = sys.argv[1]
if input('Do you want to put the library to %s?[y/n] '%ver).upper() != 'Y' :
    exit()

cwd = os.getcwd()
if sys.platform.lower()[0:3] == 'win' :
    libdir = '%s\\LibreOffice\\4\\user\\basic\\LinkXall'%os.getenv('APPDATA')
else :
    libdir = '%s/.config/libreoffice/4/user/basic/LinkXall'%os.getenv('HOME')
os.chdir(libdir)
os.system('dv.py %s *'%os.path.normpath('%s/bak/%s'%(cwd,ver)))
os.chdir(cwd)



