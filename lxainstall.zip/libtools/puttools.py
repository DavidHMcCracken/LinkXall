#!/usr/bin/env python3
# puttools.py Updated 2025.05.04.12.06
# Invoke dv.py to put scripts and help to bak/tools+
# ---------------------------------------------
import os
os.system("dv.py tools+ .py .bat .sh help")
