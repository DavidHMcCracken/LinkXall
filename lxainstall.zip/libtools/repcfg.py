#!/usr/bin/env python3
# repcfg.py Updated: 2025.05.02.12.07
# Replace the working config.txt and envar.txt with named version 
#  blank = cfg+, "." = the files here.
# --------------------------------------------------------------
import os, sys, shutil

if len(sys.argv) < 2 :
    ver = 'cfg+'
else :
    ver = sys.argv[1]
if ver != '.' :
    print('Get version %s'%ver)
    os.system('dv.py %s -get'%ver)

if sys.platform.lower()[0:3] == 'win' :
    datdir = '%s\\LibreOffice\\4\\user\\LinkXall'%os.getenv('APPDATA')
else :
    datdir = '%s/.config/libreoffice/4/user/LinkXall'%os.getenv('HOME')

print('Copy config.txt to %s'%datdir)
shutil.copy2('config.txt', datdir)
lxaenv = os.getenv('LINKXALL_ENV')
des = datdir if lxaenv == None or not os.path.exists(lxaenv) else lxaenv
print('Copy envar.txt to %s',des)
shutil.copy2('envar.txt', lxaenv)
