#!/usr/bin/env python3
# lxainstall/insupdate.py Updated: 2025.05.07.10.13
# Update components of LinkXall installer that are imported from other projects.
# This doesn't update LinkXall or doc because ../linkxall/lxaupdate.py does that
# for both lxainstall and lxaext. lxaupdate.py also updates usr/fixlxalist.py 
# here because it may be developed in the library workspace.
# *LXA-ODF*|LXADOC|LxaDesign.odt*^2InstallerWorkspace*
# --------------------------------------------------------------
import os, stat, filecmp, shutil, sys

#tailInList ----------------------------------------
# Find the index of the tail of name in a list or tuple.
# Return -1 if name's tail is not in the list.
# This is used to determine the extension of a file. e.g. 
# tailInList('name.py', ('.py', '.sh')
# ....................................................
def tailInList(name, tailist) :
    for idx,tail in enumerate(tailist) :
        if name[-len(tail):] == tail : return idx
    return -1

#cpFileRpt ------------------------------------------
# Copy file from source to destination and report the file name.
def cpFileRpt(src, des, f) :
    src = '%s/%s'%(src,f)
    if not os.path.exists(src) : return False
    print(f, end=" ")
    shutil.copy2(src, '%s/%s'%(des,f))
    return True

#mkClrDir --------------------------------------------
# Make empty directory. If the directory doesn't exist, make it. Otherwise
# delete all of its files.
# .....................................................
def mkClrDir(d) :
    if os.path.exists(d) : 
        for f in os.listdir(d) :
            os.remove('%s/%s'%(d,f))
    else :
        os.makedirs(d)

#repFile ----------------------------------------
# Replace file and report the action.
# Return False if the given source file does not exist.
# ...............................................
def repFile(src, des, f) :
    if not os.path.exists(src+f) : return False
    print('Replace %s with %s'%(des+f, src+f))
    shutil.copy2(src+f, des+f)
    return True

#updateFile --------------------------------------
def updateFile(src, des, file) :
    src = '%s/%s'%(src,file)
    des = '%s/%s'%(des,file)
    if not os.path.exists(src) : return False
    if os.path.exists(des) and \
    os.stat(des).st_mtime >= os.stat(src).st_mtime : 
        print('%s is newer than %s'%(des,src))
        return False
    print('Copy %s to %s'%(src,des))
    shutil.copy2(src, des)
    return True

#updateDir -----------------------------------------
def updateDir(src, des, flist, clr=True) :
    print('  Update', des, 'from', src)
    print(flist)
# If the destination doesn't exist, make it. Otherwise, if clr is True delete 
# its contents to prevent vestigial carryover.
    if not os.path.exists(des) :
        os.mkdir(des,mode=777)
    elif clr : 
        for f in os.listdir(des) :
            if stat.S_ISREG(os.stat(des + f)[stat.ST_MODE]) : os.remove(des + f)
    for f in flist :
        shutil.copy2(src+f, des+f)

#fexist ------------------------------------------
# If the given path exists return True else report error and return False.
def fexist(fspec) :
    if not os.path.exists(fspec) :
        print('%s does not exist'%fspec)
        return False
    else :
        return True

# ======================================================================
if sys.platform.lower()[0:3] == 'win' :
    udir = '%s\\LibreOffice\\4\\user'%os.getenv('APPDATA')
    win = True
# e.g. C:/Users/dm/AppData/Roaming/LibreOffice/4/user
else :
    udir = '%s/.config/libreoffice/4/user'%os.getenv('HOME')
    win = False
# e.g. /home/d/.config/libreoffice/4/user

datdir = '%s/LinkXall/'%udir

# ----------------------------------------------------------------
print('insupdate.py ver 2025.04.21. Update LinkXall installer imported components')
cwd = os.getcwd()
if os.path.basename(cwd) != 'lxainstall' :
    print('This can execute only in lxainstall project directory')
    exit(1)

emacsWork = '../../emacs/'
iconsWork = '../../icons/'
if fexist(emacsWork) : 
    print('\n------ EMACS ------') 
    if not os.path.exists('emacs') : os.mkdir('emacs')
    if fexist(iconsWork) :
        print('Be sure that xpm icons in %s are XPM3, required by Linux-Emacs > 26'%iconsWork)
        updateDir(iconsWork, 'emacs/', ('lxa-backlink.xpm', 'lxa-fwdlink.xpm', 
        'lxa-next.xpm', 'lxa-pin.xpm', 'lxa-prev.xpm'))
    updateDir(emacsWork, 'emacs/', ('linkxall.el', 'lemacs'), False)
    repFile(emacsWork+'wemacs/Release/', 'emacs/', 'wemacs.exe')
    des = 'emacs/wemacs/'
    if not os.path.exists(des) : os.makedirs(des)
    updateDir(emacsWork+'wemacs/', des, ('emacs.ico', 
    'resource.h', 'wemacs.cpp', 'wemacs.rc', 'wemacs.sln', 'wemacs.vcxproj',
    'wemacs.dsw', 'wemacs.dsp', 'readme.txt'))

wintopWork = '../../win/wintop/'
if fexist(wintopWork) :
    print('\n------ WINTOP ------') 
    if not os.path.exists('usr') : os.mkdir('usr')
    repFile(wintopWork+'Release/', 'usr/', 'wintop.exe')
    des = 'xsrc/wintop/'
    if not os.path.exists(des) : os.makedirs(des)
    updateDir(wintopWork, des, ('wintop.cpp', 'wintop.sln', 
    'wintop.vcxproj', 'wintop.dsw', 'wintop.dsp', 'readme.txt'))

print('\n------ LIBRARY TOOLS -------')
# Copy library support tools to libtools
src = '../linkxall'
des = 'libtools'
mkClrDir(des)
for f in os.listdir(src) :
    if f != 'fixlxalist.py' and tailInList(f, ('.py','.sh','.bat')) > -1 :
        cpFileRpt(src, des, f)
cpFileRpt(src, des, 'help')
print("")

print('\n------- CONFIG --------')
# Copy this system's config.txt and envar.txt to usr/windows or linux.
des = 'usr/windows' if win else 'usr/linux'
if not os.path.exists(des) : os.mkdir(des)
cpFileRpt(datdir, des, 'config.txt')
cpFileRpt(os.getenv('LINKXALL_ENV', datdir), des, 'envar.txt')
print("")

print('\n------- USR -----------')
cpFileRpt('../../python/pvc', 'usr', 'dv.py')
