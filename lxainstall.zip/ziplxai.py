#!/usr/bin/env python3
# This shebang is only for Linux. Without it many distros default to Python 2, 
# which cannot execute this script. Also for Linux, this file uses Unix line 
# endings. This is only for the shebang line. Python doesn't care.
#
# lxainstall/ziplxai.py Updated: 2025.05.06.13.49
# Make lxainstall.zip
# *LXA-ODF*|LXADOC|LxaDesign.odt*^2InstallerWorkspace*
# --------------------------------------------------------------
import zipfile, os, stat

ctype = zipfile.ZIP_DEFLATED

#listext ---------------------------------------------------------------
# Return a list of files with a specified extension. This is not currently
# used but could be useful.
# Arguments:
#- d is the directory in which to look for these files.
#- ext is the extension, most reliably including "." prefix.
# .......................................................................
def listext(d, ext) :
    return [f for f in os.listdir(d) if f[-len(ext):] == ext]

zf = zipfile.ZipFile('lxainstall.zip',mode='w')

#addDir -------------------------------------------------------------------
# Add directory to the zip file. 
# Arguments:
#- d is the directory
#- tree is True (default) to add subdirectories or False to add only files.
# .............................................................................
def addDir(d, tree = True) :
    print('\n   Add directory %s: '%d, end="")
    zf.write(d, compress_type = ctype)
    for f in os.listdir(d) :
        if f == 'bak' : continue
        fspec = d + '/' + f
        if stat.S_ISREG(os.stat(fspec).st_mode) :
            zf.write(fspec, compress_type = ctype)
            print(f, end = " ")
        elif tree and stat.S_ISDIR(os.stat(fspec).st_mode) :
            addDir(fspec, tree)

for d in ('LinkXall','doc','BasicIDE','swriter','usr','xsrc','emacs','pgm', 'libtools') : 
    addDir(d) 

print('\n   Add root files: ', end = "")
# Leave out bas because it is a copy of the embedded library only for version
# control (dvcfg). lxainstall.zip is the file we are making. 
for f in os.listdir() :
    if os.path.isfile(f) and not f in ['lxainstall.zip', 'bas'] :
        print(f, end= " ")
        zf.write(f, compress_type = ctype)
print()
zf.close()

