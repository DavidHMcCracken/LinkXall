#!/usr/bin/env python3
# lxainstall/putbasicide.py Updated 2025.05.04.10.31
# Copy the files in BasicIDE, BasicIDE/images, and BasicIDE/images/Bitmaps into
# BasicIDEbak to flatten the tree for version control (in BasicIDEbak) and
# general backup. In BasicIDEbak invoke dv to put all files into v+ in local
# (sub-project) bak repository.
# --------------------------------------------------------------------------
import sys, os, shutil

dst = 'BasicIDEbak'
if not os.path.exists(dst) : os.mkdir(dst)
for src in ('BasicIDE', 'BasicIDE/images', 'BasicIDE/images/Bitmaps') :
    for f in os.listdir(src) :
        sf = '%s/%s'%(src,f)
        if os.path.isfile(sf) :
            print(sf)
            shutil.copy2(sf, dst)
os.chdir(dst)
os.system('dv.py v+ *')
