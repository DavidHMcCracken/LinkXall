#!/usr/bin/env python3
# lxainstall/putins.py Updated 2025.05.10.14.35
import os
os.system("dv.py ins+ .xcu .xml")
