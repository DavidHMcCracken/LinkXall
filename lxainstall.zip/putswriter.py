#!/usr/bin/env python3
# lxainstall/putswriter.py updated 2025.05.04.10.32
# Copy the files in swriter, swriter/images, and swriter/images/Bitmaps into
# swriterbak to flatten the tree for version control (in swriterbak) and
# general backup. In swriterbak invoke dv to put all files into v+ in local
# (sub-project) bak repository.
# --------------------------------------------------------------------------
import sys, os, shutil

dst = 'swriterbak'
if not os.path.exists(dst) : os.mkdir(dst)
for src in ('swriter', 'swriter/images', 'swriter/images/Bitmaps') :
    for f in os.listdir(src) :
        sf = '%s/%s'%(src,f)
        if os.path.isfile(sf) :
            print(sf)
            shutil.copy2(sf, dst)
os.chdir(dst)
os.system('dv.py v+ *')
