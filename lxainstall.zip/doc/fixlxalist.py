#!/usr/bin/env python3
# This shebang is only for Linux. Without it many distros default to Python 2, 
# which cannot execute this script. Also for Linux, this file uses Unix line 
# endings. This is only for the shebang line. Python doesn't care.
#
# fixlxalist.py
# Updated: 2023.05.28.17.28
# Add or fix the LXAlist style in a Libre document or template (odt or ott file). 
#
# Conceptually, we only want to replace the styles.xml file in the document 
# but Python's zipfile module does not provide a means of doing this. As a 
# workaround we iterate over all elements of the document, adding them to a 
# temporary file without any change except styles.xml. If that contains an 
# LXAlist style it is replaced with the good style. Otherwise, the style is 
# inserted after the first existing list style. When the temporary document is 
# complete, it replaces the original. A backup copy of the original is saved 
# before replacing it.
#
# *LXA-ODF*|LXADOC|LxaDesign.odt*^2fixlxalist*
# ------------------------------------------------------------------------------
import zipfile, sys, os, stat

lxalist = b'<text:list-style style:name="LXAlist"><text:list-level-style-number text:level="1" style:num-suffix=":" style:num-format="1"><style:list-level-properties text:list-level-position-and-space-mode="label-alignment"><style:list-level-label-alignment text:label-followed-by="space" fo:text-indent="-0.1in" fo:margin-left="0.1in"/></style:list-level-properties></text:list-level-style-number><text:list-level-style-number text:level="2" style:num-suffix=":" style:num-format="1"><style:list-level-properties text:list-level-position-and-space-mode="label-alignment"><style:list-level-label-alignment text:label-followed-by="space" fo:text-indent="-0.1in" fo:margin-left="0.3in"/></style:list-level-properties></text:list-level-style-number><text:list-level-style-number text:level="3" style:num-suffix=":" style:num-format="1"><style:list-level-properties text:list-level-position-and-space-mode="label-alignment"><style:list-level-label-alignment text:label-followed-by="space" fo:text-indent="-0.1in" fo:margin-left="0.5in"/></style:list-level-properties></text:list-level-style-number><text:list-level-style-number text:level="4" style:num-suffix=":" style:num-format="1"><style:list-level-properties text:list-level-position-and-space-mode="label-alignment"><style:list-level-label-alignment text:label-followed-by="space" fo:text-indent="-6.4in" fo:margin-left="7in"/></style:list-level-properties></text:list-level-style-number><text:list-level-style-number text:level="5" style:num-suffix=":" style:num-format="1"><style:list-level-properties text:list-level-position-and-space-mode="label-alignment"><style:list-level-label-alignment text:label-followed-by="space" fo:text-indent="-0.1in" fo:margin-left="0.9in"/></style:list-level-properties></text:list-level-style-number><text:list-level-style-number text:level="6" style:num-suffix=":" style:num-format="1"><style:list-level-properties text:list-level-position-and-space-mode="label-alignment"><style:list-level-label-alignment text:label-followed-by="space" fo:text-indent="-0.1in" fo:margin-left="1.1in"/></style:list-level-properties></text:list-level-style-number><text:list-level-style-number text:level="7" style:num-suffix=":" style:num-format="1"><style:list-level-properties text:list-level-position-and-space-mode="label-alignment"><style:list-level-label-alignment text:label-followed-by="space" fo:text-indent="-0.1in" fo:margin-left="1.3in"/></style:list-level-properties></text:list-level-style-number><text:list-level-style-number text:level="8" style:num-suffix=":" style:num-format="1"><style:list-level-properties text:list-level-position-and-space-mode="label-alignment"><style:list-level-label-alignment text:label-followed-by="space" fo:text-indent="-0.1in" fo:margin-left="1.5in"/></style:list-level-properties></text:list-level-style-number><text:list-level-style-number text:level="9" style:num-suffix=":" style:num-format="1"><style:list-level-properties text:list-level-position-and-space-mode="label-alignment"><style:list-level-label-alignment text:label-followed-by="space" fo:text-indent="-0.1in" fo:margin-left="1.7in"/></style:list-level-properties></text:list-level-style-number><text:list-level-style-number text:level="10" style:num-suffix=":" style:num-format="1"><style:list-level-properties text:list-level-position-and-space-mode="label-alignment"><style:list-level-label-alignment text:label-followed-by="space" fo:text-indent="-0.1in" fo:margin-left="1.9in"/></style:list-level-properties></text:list-level-style-number></text:list-style>'

if len(sys.argv) < 2 :
    print('fixlxalist.py fixes or adds LXAlist style to an odt document.')
    exit(0)
doc = sys.argv[1]

if not os.path.isfile(doc) :
    print(doc, 'does not exist')
    exit(1)

if 0 == stat.S_IMODE(os.stat(doc)[stat.ST_MODE]) & stat.S_IWRITE :
    print(doc, 'is read only')
    exit(1)

bext = os.path.splitext(doc)
if bext[1].lower() != '.odt' and bext[1].lower() != '.ott' :
    print(doc, 'is not an odt or ott file')
    exit(1)

try : os.rename(doc, doc)
except OSError as err :
    print(doc, 'must be closed before we can modify it')
    exit(1)

tfname = 'tempWithLxa.odt'
z = zipfile.ZipFile(doc, mode='r')
zout = zipfile.ZipFile(tfname, mode = 'w')
inflist = z.infolist()
for item in inflist :
    text = z.read(item)
    if item.filename == 'styles.xml' : 
        i1 = text.find(b'<text:list-style style:name="LXAlist">')
        if i1 >= 0 :
            i2 = text[i1 + 38 : -1].find(b'</text:list-style>')
            tail = text[i1 + i2 + 56 :]
        else :
            i1 = text.find(b'</text:list-style>') + 18
            tail = text[i1 : ]
        text = text[0 : i1] + lxalist + tail
    zout.writestr(item, text)
zout.close()
z.close()

bakfile = bext[0] + 'Bak' + bext[1]
if os.path.isfile(bakfile) : os.remove(bakfile)
os.rename(doc, bakfile)
os.rename(tfname, doc)
print('LXAlist has been fixed in', doc, 'with original saved as', bakfile)
