
// wemacs.cpp  
// Updated: 2024.04.10.17.19
//
//                         PURPOSE
// Invoke Emacs and evaluate the given expressions, if any. In all variations 
// this first tries to open Emacs through emacsclient, which avoids creating 
// multiple instances of the program. This can fail for a variety of reasons 
// but the most common is that there isn't already executing an instance of 
// emacs acting as server for emacsclient. To test this, emacsclient is invoked
// again but with an error message. If the failure was due to the arguments 
// rather than emacsclient, this will succeed. If it fails, emacs is invoked 
// with the arguments plus the command to start the server. The emacs program 
// automatically brings the window forward and gives it input focus but 
// emacsclient does not. wemacs fixes this. (The Linux equivalent of this 
// program is lemacs BASH script).
//
// wemacs is intended for both interactive use and for use by other programs, 
// notably Open/Libre Office BASIC macros, that have limited system function 
// support. ooBasic macros can't know whether anything they spawn succeeds. 
// Additionally, the direct emacs command invocation text is very difficult 
// (impossible in some cases) to create in a way that can survive transit 
// through the command interpreter, which is the only means of invoking an 
// external program in some macro systems. To serve in this capacity, wemacs 
// has some hard-wired functions. Knowing the purpose enables wemacs to effect 
// remediation and minimizes the complexity of dynamic text that the macro must 
// create. 
//
// wemacs affords a superior means of invoking Emacs interactively or as 
// default program for specified file types. The proliferation of independent 
// instances of Emacs by direct invocation wastes display space and reduces 
// operational sharing, e.g. applying an edit to all buffers. But emacsclient 
// has a high coordination cost and, without elevating the window, is not only 
// inconvenient but dangerous. Further, if linkxall is being used, a file opened
// by direct invocation of emacs will not fully participate in all hyperlinking 
// unless the server is running, but this cannot be done automatically (i.e. 
// in .emacs) without raising a warning.
//
//                        EMACS CONFIGURATION
//             (setq frame-title-format "Emacs>%f") 
// Elevation of an existing Emacs window works best if some or all of the file 
// name is included in the title. Otherwise, wemacs will elevate the first 
// Emacs window it finds. The title need not contain "Emacs" because candidates 
// are filter by window class name, which is Emacs. However, "Emacs>" does not 
// take much space and helps to clarify the situation, especially when the 
// window is minimized. In .emacs the assignment (setq frame-title-format 
// "Emacs>%f") meets this with the full filespec, which is useful in its own 
// right, but %b, which shows only the file (buffer) name, is sufficient.
//
// Emacs does not itself have to start the server to support emacsclient 
// because this program will do that if emacsclient fails. However, it is 
// impossible to communicate with an instance of emacs that is not already 
// running as server. In that case, wemacs will start another instance and make 
// it server and the two instances will have no status or data in common. 
//   Putting (server-start nil t) ; LEAVE-DEAD = nil, INHIBIT-PROMPT = t in 
// .emacs would limit the proliferation of instances but also cause Emacs to 
// issue a distracting warning about the server on every invocation of emacs 
// after the first. That does not happen with wemacs, which always first tries 
// emacsclient but it can happen frequently if emacs is the default application 
// for various types of plain text files.
//   A much better solution is to make wemacs the default program for text 
// files and to invoke it instead of emacs or emacsclient at command prompts. 
// This not only eliminates instance proliferation without increasing warnings 
// but also elevates an existing Emacs window, which emacsclient itself doesn't 
// do. Further, there is no coordination cost, as there is with a daemon Emacs.
// 
//                         TRY-RETRY PATTERNS
// Some invocation patterns, notably text search, frequently fail and we don't 
// want to simply assume that missing server is always the problem, as each new 
// invocation of Emacs creates an entirely independent instance (and confusing 
// messages if each tries to register itself as "the" server). For those cases, 
// if emacsclient initially fails we invoke it again but with a different 
// command, which usually describes the failure. If this succeeds the problem 
// was not missing server but failure of the initial command and the Emacs 
// window remains open, reporting the problem. If it fails again, the user
// won't see our error message; emacs (runemacs) is invoked with the original
// commands plus server-start.
//
//                          Emacsclient Fail
// emacsclient won't tell us the cause of failure because it prints error to 
// its own private window and has only one failure exit value. The most common 
// cause is that emacs is not running or not serving but string search failure 
// is also common. The former is corrected by launching emacs but this just 
// makes things worse in case of search failure. Therefore, if emacsclient 
// fails and there is a search, we try it again with the search operation 
// replaced by message that the search string can't be found.
// 
//                             RUNEMACS
// Emacs is not invoked directly, which creates an inactive command window 
// (only in Windows), but by runemacs. Unless emacsclient and runemacs (or bat 
// files that invoke them) are in the exe path, the system environment variable 
// EMACSEXEPATH must tell their directory. The value must use / path delimiter 
// and end in delimiter. e.g. "C:/programs/Emacs/bin/". EMACSEXEPATH is 
// deliberately not a variable recognized by Emacs itself. The exe path 
// variables used by Emacs are multi-paths, complicating their use.
//
//                             EMACSCLIENT
// _P_WAIT _tspawnlp is used with emacsclient to get its exit code before 
// continuing but emacsclient is invoked no wait. This requires either -n or -e 
// option. Since eval1 virtually always comprises at least one --eval command, 
// there is no need for additional -n or -e argument. Although we don't know 
// what eval1 might contain in raw command line mode, it is of little value 
// without an eval argument and it can include -n if needed.
//
//                         VERBOSITY (SHOW)
// When used interactively (by the user in a terminal window) there is a window 
// to display errors. Otherwise, any messages it echos either don't display at 
// all or briefly flash in a window that immediately closes. Having no feedback 
// would particularly complicate developing correctly formed command arguments 
// in scripts, where nested quoting requirements are very difficult to meet. 
// The command line options argument includes a field that tells what to show 
// and one that tells how to show. By default, only errors are shown and it is 
// by echo to console with nothing to prop the the window open. This is useful 
// only interactively. 
//
//                      SECURE FUNCTIONS
// Warning C4996 _CRT_SECURE_NO_WARNINGS is disabled because in some cases
// "unsafe" functions are used instead of their "safe" alternatives, which 
// unnecessarily corrupt adjacent memory unless the size limit is precisely 
// computed. 
//
//                      MODES
// 0 = raw
// 1 = do nothing
// 2 = open file and invoke emacs function
// 3 = open file and go to line
// 4 = open file and search from the beginning
// 5 = open file and search from current
// If linkxall.el is operating, mode 2 with function lxa-xcmd should be used 
// instead of higher modes. It is more flexible, efficient, and reliable.
//
//                       EXAMPLES
// wemacs file. Normal interactive.
// wemacs -2 c:\swdev\emacs\lxatest.el lxa-xcmd 3 "*LXA-"
// wemacs -3 file line. Open file and go to line, reporting only errors.
// wemacs -4 file string. Search for string from beginning of file.
// wemacs -5 file string. Search from current location.
// wemacs -111 anything. Report all parameters to console and hold open.
// wemacs -213 file line. Open file and go to line. Report everything to 
//  %HOME%\echofile.
// wemacs -314 myerrors file string. Open file and search for string. Report
//  everything to myerrors.
// wemacs -23 file line. Open file and go to line. Completely silent.
// ............................................................................

#include <stdio.h>
#include <process.h>
#include <tchar.h>
#include <stdarg.h>
#include <sys/stat.h>
#include <windows.h>
#include <conio.h>
#include <time.h>

#pragma warning(disable : 4996)
#define DIM(A) (sizeof(A)/sizeof(A[0]))
#define HELPMSG(S) _tprintf(_T(S))
enum howshow { HOW_CON, HOW_PAUSE, HOW_DEFILE, HOW_FILE };
enum whatshow { WHAT_ERR, WHAT_ALL, WHAT_SILENT };
HWND    emacsWindow = 0;
int     showHow = HOW_CON;
int     show = WHAT_ERR;
FILE*   fecho = stdout;

// ---------------------------- repChar -----------------------------------
// Replace every instance of one character with another.
void repChar(TCHAR* str, TCHAR findc, TCHAR repc)
{
    for (TCHAR* cp = str; *cp != 0; cp++)
        if (*cp == findc)
            *cp = repc;
}   // repChar

// --------------------------- filename --------------------------------
// Find the filename in the given filespec (path + filename). 
// Returns: pointer to the file name in filespec, i.e. not a copy.
// Arguments: fspec is any portion of absolute or relative path plus the
// file name. It may be just the filename. 
// This basically looks for the last / or \, returning pointer to the next 
// char. If no path delim is found filespec is the filename except when 
// filespec includes drive, e.g. D:myfile. Any drive specifier is skipped.
// .......................................................................
TCHAR* filename(TCHAR* fspec)
{
    TCHAR*  bp;
    TCHAR*  sp;
    if (fspec == 0)
        return 0;
    bp = _tcschr(fspec, ':');
    bp = bp == 0 ? fspec : bp + 1;
    sp = _tcsrchr(bp, _TCHAR('/'));
    if (sp == 0)
        sp = _tcsrchr(bp, _TCHAR('\\'));
    return sp == 0 ? bp : sp + 1;
}   // filename

// ---------------------------------- EwProc --------------------------------
// Elevate Emacs window to top of Z-stack and give it the focus. This is a 
// callback from EnumWindows, which passes the handle of each top-level (no 
// children) window until either this function returns false or all windows 
// have been visited. LPARAM lp, if not null, points to the file name or a 
// portion of it, which must be included in the window's title for us to find 
// it. If lp is null then the first emacs window found is selected. 
//
// Global HWND emacsWindow is assigned the selected window's handle to signal 
// success and in case the caller wants to do something else to the window.
//
// The window's class name, "Emacs", is used to filter candidates instead of
// looking for emacs in the window's title because the window of a folder
// called Emacs will have the title "Emacs". If a file has been specified
// the folder would be rejected for not having the file name but, with no
// arguments we want to open Emacs, which won't happen if EwProc indicates
// that it has found and elevated the fake Emacs window.
// .......................................................................
BOOL CALLBACK EwProc(HWND hw, LPARAM lp)
{
    TCHAR name[200];

    if (IsWindow(hw) && GetClassName(hw, name, DIM(name)) != 0 &&
        _tcscmp(name, _T("Emacs")) == 0)
    {
        GetWindowText(hw, name, DIM(name));
        if (lp == 0 || _tcsstr(name, (TCHAR*)lp) != 0)
        {
            SetForegroundWindow(hw);
            emacsWindow = hw;
            return false;
        }
    }
    return true;
}   // EwProc

//--------------------------------- waitForUser --------------------------------
void waitForUser(void)
{
    _tprintf(_T("Press any key to continue."));
    getch();
    _tprintf(_T("\n"));
}   // waitForUser

// -------------------------------- echo -------------------------------------
// Print the given message and conditionally hold the console window open by
// waiting for keyboard input. This always returns true, enabling it to be 
// invoked in a complex predicate without impinging on the logic.
// ...............................................................
bool echo(const TCHAR * const fmt, ...)
{
    va_list argptr;
    if (show != WHAT_SILENT)
    {
        va_start(argptr, fmt);
        _vftprintf(fecho, fmt, argptr);
        va_end(argptr);
        if (showHow == HOW_PAUSE)
            waitForUser();
    }
    return true;
}

TCHAR   Emacs[] = _T("runemacs");
TCHAR   eval1[1000] = _T("");
TCHAR   eval2[500] = _T("");
TCHAR*  pexe;
size_t  pathlen;

int startServer(void)
{
    _tcscpy(pexe + pathlen, Emacs);
    if (show == WHAT_ALL)
        echo(_T("Call %s with --eval \"(server-start)\" %s %s\n"), pexe, eval1, eval2);
    else
        _tprintf( _T("****** Wemacs: Invoking Emacs in server mode ******\n"));
    return _tspawnlp(_P_NOWAIT, pexe, Emacs, _T(" --eval \"(server-start)\""), eval1, eval2, 0);
}

boolean isHelpRequest(_TCHAR *arg)
{
    switch (_tcslen(arg))
    {
    case 1:
        return arg[0] == _TCHAR('?');
    case 2:
        if( (arg[0] == _TCHAR('-') || arg[0] == _TCHAR('/')) && 
            (arg[1] == _TCHAR('H') || arg[1] == _TCHAR('h')) )
            return true;
    }
    return false;
}

// ------------------------------- main -----------------------------------
int __cdecl _tmain(int argc, _TCHAR **argv, _TCHAR **envp)
{
    TCHAR   EmacsClient[] = _T("emacsclient");
    TCHAR   eval3[500] = _T("");
    TCHAR*  fspec = 0;
    int     mode = -1;
    int     emarg = 1; // First Emacs arg after any options.

    TCHAR*  exePath;
    struct  _stat fs;
    int     idx;

    if ( argc > 1 && isHelpRequest(argv[1]) )
    {
HELPMSG("wemacs.exe 2024.04.10\n");
HELPMSG("Server mode Emacs. Open Emacs through emacsclient if possible else\n");
HELPMSG(" invoke emacs (runemacs) as server for emacsclient.\n");
HELPMSG("With no parameters, make existing Emacs window top or if none then\n");
HELPMSG(" open Emacs as server.\n");
HELPMSG("?, -h, -H, /h, or /H display this help.\n");
HELPMSG("-nonNumber: Raw mode. Pass all parameters, including this, to Emacs.\n");
HELPMSG("-number: wemacs options: 100's = show how, 10's = show what, 1's = mode.\n");
HELPMSG("Show how: 0 = console, 1 = pause console, 2 = default file\n");
HELPMSG(" (%%HOME%%\\echofile), 3 = file identified by next parameter.\n");
HELPMSG("Show what: 0 = only fatal errors, 1 = all, 2 = silent.\n");
HELPMSG("Mode 0: Raw mode with options. e.g. -310 myechofile ... Emacs parameters ...\n");
HELPMSG("Mode 1: do nothing. e.g. -11 to see invocation parameters.\n");
HELPMSG("All other modes require the next parameter to be path+name of an existing\n");
HELPMSG(" file. If it does not exist, wemacs aborts. They expect another parameter\n");
HELPMSG(" but if it isn't given they just open the file.\n");
HELPMSG("Mode 2: the next parameter is any Emacs function and the rest are arguments\n");
HELPMSG("Mode 3: the next parameter is a line number to go to.\n");
HELPMSG("Mode 4: the next parameter is text to be searched for from the\n");
HELPMSG(" the beginning of the file.\n");
HELPMSG("Mode 5: the next parameter is text to be searched for from the current\n");
HELPMSG(" file location (the beginning if not already open).\n");
HELPMSG("Environment variable EMACSEXEPATH path (.../Emacs/bin/) to emacs.exe is required.\n");
        exit(0);
    }
    if (argc > 1 && *argv[1] == TCHAR('-') && _istdigit(argv[1][1]))
    {
        TCHAR echofile[_MAX_PATH] = _T("");
        emarg = 2; // wemacs -nnn firstEmacsArg
        idx = _ttoi(argv[1] + 1);
        mode = idx % 10;
        show = (idx / 10) % 10;
        showHow = idx / 100;
        if ( showHow == HOW_DEFILE ) 
        {
            TCHAR *home = _tgetenv(_T("HOME"));
            if (home != 0)
            {
                _tcscpy(echofile, home);
                _tcscat(echofile, _T("\\"));
            }
            _tcscat(echofile, _T("echofile"));
         }
        else if ( showHow == HOW_FILE )
        {
            if (argc < 3)
            {
                HELPMSG("ShowHow 3 requires that an echo file be specified.\n");
                exit(1);
            }
            _tcscpy(echofile, argv[2]);
            emarg = 3; // wemacs -3nn file firstEmacsArg
        }
        if (echofile[0] != 0)
        {
            fecho = _tfopen(echofile, _T("wt"));
            if ( fecho == 0 )
            {
                _tprintf(_T("Unable to open echo file %s\n"), echofile);
                exit(1);
            }
            time_t dateTime = time(0);
            echo( _tctime(&dateTime));
        }
     }
    
    if ( show == WHAT_ALL )
    {
        for ( idx = 0; idx < argc ; idx++ )
            _ftprintf( fecho, _T("\"%s\"\n"), argv[idx]);
        if ( showHow == HOW_PAUSE )
            waitForUser();
    }

	exePath = _tgetenv(_T("EMACSEXEPATH"));
	if(exePath == 0)
		pathlen = 0;
	else
		pathlen = _tcsclen(exePath);

    pexe = new TCHAR[pathlen + 21];
    if (pathlen > 0)
    {
		_tcscpy(pexe, exePath);
        if (pexe[pathlen - 1] != TCHAR('/') && pexe[pathlen - 1] != TCHAR('\\'))
		{
            _tcscpy(pexe + pathlen, _T("\\")); 
			pathlen++;
		}
    }
    _tcscpy(pexe + pathlen, _T("emacsclient.exe"));
    if (_tstat(pexe, &fs) != 0 || !(fs.st_mode & _S_IFREG))
    {
        echo(_T("\"%s\" does not exist. %%EMACSEXEPATH%% \"%s\" is incorrect\n"), 
            pexe, exePath);
        exit(1);
    }
    if (mode == 1) // Do nothing. e.g. -211 to show args in default echo file.
        exit(0);
// The following unconditional message is slightly distracting if emacsclient
// executes without problems but doesn't increase the duration of the temporary
// console window and is useful for a fresh invocation or if emacsclient
// pauses to display an error message. e.g. linkxall.el lxa-xcmd failed search
// for string.
    _tprintf(_T("\n****** Wemacs: This may take a few seconds ******\n")); 

    if ( mode < 2 && argc == emarg ) // No Emacs args and none required (mode < 2).
    {
    // If any current window has title that begins "emacs" (case-insensitive) then 
    // make it top. Otherwise, start Emacs as server (for emacsclient).
        EnumWindows(EwProc, (LPARAM)0);
        if (emacsWindow == 0)
            return startServer();
        return 0;
    }

    if (mode < 1) // Raw either by default -1 or -nn0
    {
        for (idx = emarg; idx < argc; idx++)
            _stprintf(eval1 + _tcsclen(eval1), _T(" \"%s\" "), argv[idx]);
    }

    else // ..................... Modes 2+ ............................
    {
        if ( argc < emarg + 1 )
        {   
            echo(_T("For wemacs mode %d a file must be specified.\n"), mode);
            exit(1);
        }
        fspec = argv[emarg];
        if (_tstat(fspec, &fs) != 0 || !(fs.st_mode & _S_IFREG))
        {
            echo(_T("File \"%s\" does not exist\n"), fspec);
            exit(2);
        }
        repChar(fspec, TCHAR('\\'), TCHAR('/')); // Replace any \ in filespec with / to avoid escape error. 
#ifdef _stprintf_s
        _stprintf_s(eval1, 500, _T(" --eval \"(find-file \\\"%s\\\")\""), fspec); 
#else
		_stprintf(eval1, _T(" --eval \"(find-file \\\"%s\\\")\""), fspec);
#endif
        _stprintf(eval3, _T("--eval \"(message \\\"Command error\\\")\"")); // Default error command
        emarg++;
        if (argc > emarg ) // These all expect an additional argument but don't require it.
        {
            switch (mode) {
            case 2: // Invoke given function with all remaining arguments, each one quoted.
                _stprintf(eval2, _T(" --eval \"(%s"), argv[emarg]); // e.g. --eval "(lxa-xcmd
                for (idx = emarg + 1; idx < argc; idx++)
                    _stprintf(eval2 + _tcsclen(eval2), _T(" \\\"%s\\\" "), argv[idx]);
                _stprintf(eval2 + _tcsclen(eval2), _T(")\"")); // )"
                // e.g. --eval "(lxa-xcmd \"3\"  \"something\"  \"I don't care\" )"
                break;
            case 3: // Go to line
#ifdef _stprintf_s
                _stprintf_s(eval2, 500, _T(" --eval \"(goto-line %d)\""), _ttoi(argv[emarg]));
#else
				_stprintf(eval2, _T(" --eval \"(goto-line %d)\""), _ttoi(argv[emarg])); 
#endif
                break;
            case 4: // Search from beginning
                _tcscpy(eval2, _T(" --eval \"(beginning-of-buffer)\""));
            // Fall through to search from current.
            case 5: // Search from current
                _stprintf(eval2 + _tcsclen(eval2),
                    _T(" --eval \"(search-forward \\\"%s\\\")\""), argv[emarg]);
                _stprintf(eval3,
                    _T("--eval \"(message \\\"%s not found\\\")\""), argv[emarg]);
                break;
            }
        } 
    }
    _tcscpy(pexe + pathlen, EmacsClient);

    if (show == WHAT_ALL)
        echo(_T("Call %s with -n %s %s\n"), pexe, eval1, eval2);
// With _P_WAIT _tspawnlp is synchronous and returns the process exit code, 0 = 
// success. If emacsclient fails with requested commands then try invoking it 
// to show error message (eval3). If either succeeds, make the Emacs window top-
// most. If they both fail, emacs server is not running, so invoke emacs with 
// the requested commands plus server-start. 
    if (_tspawnlp(_P_WAIT, pexe, EmacsClient, _T("-n"), eval1, eval2, 0) == 0 ||
        (show != WHAT_ALL || echo(_T("Call %s with -n %s\n"), pexe, eval3)) &&
        _tspawnlp(_P_WAIT, pexe, EmacsClient, _T("-n"), eval3, 0) == 0)
        EnumWindows(EwProc, (LPARAM)filename(fspec));
    else
        startServer();
    return 0;
 }   // main
