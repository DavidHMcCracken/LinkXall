#!/usr/bin/env python3
# This shebang is only for Linux. Without it many distros default to Python 2, 
# which cannot execute this script. Also for Linux, this file uses Unix line 
# endings. This is only for the shebang line. Python doesn't care.
#
# lxaupdate.py Updated: 2025.05.23.13.12
# Update LinkXall and doc folders of the installer and extension workspaces. 
# This also updates fixlxalist.py in lxainstall/usr because that may be 
# developed here or under python workspace. The installer's insupdate.py gets 
# Emacs and wintop source files itself. It also gets the library tools from 
# here because that is simply a matter a copying the script files.
#- This must be invoked in swdev/libre/linkxall.
#- LinkXall must be installed as user library. The library files are copied
# from LibreUser/basic/LinkXall to LinkXall in the installer and extension
# projects.
# *LXA-ODF*|LXADOC|LxaDesign.odt*^2ProjectWorkspace*
# --------------------------------------------------------------
import os, stat, filecmp, shutil, sys

#repFile ----------------------------------------
def repFile(src, des, f) :
    if not os.path.exists(src+f) : return False
    print('Replace %s with %s'%(des+f, src+f))
    shutil.copy2(src+f, des+f)
    return True

#updateFile --------------------------------------
def updateFile(src, des, file = "") :
    if file != "" :
        src = '%s/%s'%(src,file)
        des = '%s/%s'%(des,file)
    if not os.path.exists(src) : return False
    if os.path.exists(des) and \
    os.stat(des).st_mtime >= os.stat(src).st_mtime : return False
    print('Copy %s to %s'%(src,des))
    shutil.copy2(src, des)

#updateDir -----------------------------------------
def updateDir(src, des, flist, clr=True) :
    print('  Update', des, 'from', src)
    print(flist)
# If the destination doesn't exist, make it. Otherwise, if clr is True delete 
# its contents to prevent vestigial carryover.
    if not os.path.exists(des) :
        os.mkdir(des,mode=777)
    elif clr : 
        for f in os.listdir(des) :
            if stat.S_ISREG(os.stat(des + f)[stat.ST_MODE]) : os.remove(des + f)
    for f in flist :
        shutil.copy2(src+f, des+f)

#fexist ------------------------------------------
# If the given path exists return True else report error and return False.
def fexist(fspec) :
    if not os.path.exists(fspec) :
        print('%s does not exist'%fspec)
        return False
    else :
        return True

# ======================================================================
if sys.platform.lower()[0:3] == 'win' :
    udir = '%s\\LibreOffice\\4\\user'%os.getenv('APPDATA')
    win = True
# e.g. C:/Users/dm/AppData/Roaming/LibreOffice/4/user
else :
    udir = '%s/.config/libreoffice/4/user'%os.getenv('HOME')
    win = False
# e.g. /home/d/.config/libreoffice/4/user
libdir = '%s/basic/LinkXall/'%udir
datdir = '%s/LinkXall/'%udir

lxaExt = '../lxaext/'
lxaExtLib = lxaExt + 'LinkXall/'
lxaExtDoc = lxaExt + 'doc/'

lxaIns = '../lxainstall/'
lxaInsLib = lxaIns + 'LinkXall/'
lxaInsDoc = lxaIns + 'doc/'
lxaInsUsr = lxaIns + 'usr/'

# ----------------------------------------------------------------
print('lxaupdate.py ver 2025.03.17. Update LinkXall installer and extension components.')
cwd = os.getcwd()
if os.path.basename(cwd) != 'linkxall' :
    print('This can execute only in linkxall project directory')
    exit(1)

# LinkXall must be installed as user library and the installer and extension
# directories must already exist because they are independent projects.
for d in (libdir, datdir, lxaIns, lxaExt) :
    if not fexist(d) : exit(1)

# Make sure that the installer and extension projects have the expected 
# sub-directories
for d in (lxaExtLib, lxaExtDoc, lxaInsLib, lxaInsDoc, lxaInsUsr ) :
    if not os.path.exists(d) : os.makedirs(d)

# Update installer and extension LinkXall from the current working version
# of the library .../LibreOffice/4/user/basic/LinkXall. First extract the
# version from LinkXall.xba.
ver = ""
with open('%s/LinkXall.xba'%libdir, mode = 'r+t') as df :
    for cnt in range(20) :
        li = df.readline()
        if li.find('const version') > -1 :
            i1 = li.find('&quot;') + 6
            i2 = li.find('&quot;', i1)
            ver = li[i1:i2]
            break
    else :
        print('Unable to find version statement')
if ver != "" :
    with open('libver', mode = 'w') as df : df.write(ver)

print('\n------ LIBRARY ------') 
for des in (lxaExtLib, lxaInsLib) :
    updateDir(libdir, des, os.listdir(libdir))
    print("")
shutil.copy2('libver', lxaIns)
shutil.copy2('libver', lxaExt)

# ----------- ANCILLARY PROJECTS AND DOCUMENTATION -----------
# LxaUserGuide.odt, LxaDesign.odt, and lxaupdate.py (this file) are developed 
# in this (linkxall project) directory and are copied from here into lxainstall
# and lxaext doc directories. LXADesign.odt references source code for several
# ancillary projects, which may be developed here or in other venues or not at 
# all in this system. These files are copied from docrefs linkxall project 
# directory into lxainstall and lxaext doc directories. Before doing this, if 
# their project directories exist, they are added to the installer and their 
# source files copied into docrefs and LibreUser/LinXall, the data directory, 
# which also serves as the default doc directory, updating local references.

docrefs = '%s/docrefs/'%cwd
if not os.path.exists(docrefs) : os.mkdir(docrefs)
refcnt = 0 # Number of ancillary projects under development in this system.

print('\n------ FIXLXALIST ------') 
# fixlxalist.py may be developed here or in python projects. If it exists there
# and is newer then update here. In any case, update docrefs and installer usr
# from here.
updateFile('../../python/fixlxalist/fixlxalist.py', '%s/fixlxalist.py'%cwd)
updateFile(cwd, docrefs, 'fixlxalist.py')
updateFile(cwd, lxaInsUsr, 'fixlxalist.py')

print('\n------ DOCUMENTS ------') 

# Update Emacs doc references if the emacs workspace exists in this system.
emacsWork = '../../emacs/'
if fexist(emacsWork) : 
    for f in ('linkxall.el', 'lemacs') :
        updateFile(emacsWork + f, docrefs + f)
        updateFile(emacsWork + 'wemacs/wemacs.cpp', docrefs + 'wemacs.cpp')
        refcnt += 1

# Update wintop doc references if the wintop workspace exists in this system.
wintopWork = '../../win/wintop/'
if fexist(wintopWork) :
    updateFile(wintopWork + 'wintop.cpp', docrefs + 'wintop.cpp')
    refcnt += 1

for des in (lxaIns + 'doc/', lxaExt + 'doc/') :
    updateDir('./', des, ('LxaUserGuide.odt', 'LxaDesign.odt', 'LxaTut.odt', \
    'lxaupdate.py'), refcnt == 2) # If all ancillary projects are under development in this 
# system then pre-clear the doc directories to avoid obsolete carry-overs. 
# Otherwise, docrefs may be incomplete and not able to replace all doc refs.
updateFile(lxaIns + 'LxaInstall.odt', docrefs + 'LxaInstall.odt')
for des in (lxaIns + 'doc/', lxaExt + 'doc/', datdir) :
    for d in os.listdir(docrefs) :
        updateFile(docrefs + d, des + d)
