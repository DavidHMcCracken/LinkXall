
// wintop.cpp  
// Updated: 2023.05.19
//
//                         PURPOSE
// Make foreground(top and focus) a window whose title contains the given text.
// This could easily do more with one or more windows by invoking SetWindowPos 
// instead of SetForegroundWindow but Windows 10 won't let us do that unless 
// this program is run as Admin, which imposes a user query at every 
// invocation. If that is acceptible, use winmove.
//                         USE
// This is intended for use by another program, e.g. LO Basic LinkXall. It 
// cannot be invoked from a command prompt even for testing because of a 
// Windows 10 stupidity. A dummy window whose title contains the command line 
// will appear in enumeration and be seen as the window being sought. The same 
// command line in a bat file will work correctly, affording a relatively 
// simple means of testing.
// .........................................................................

#include <tchar.h>
#include <windows.h>
#include <stdio.h>

#pragma warning(disable : 4996)
#define DIM(A) (sizeof(A)/sizeof(A[0]))
#define HELPMSG(S) _tprintf(_T(S))

HWND wndMatch = 0;

// ---------------------------------- EnumProc --------------------------------
// Callback from EnumWindows.
// If the given window's title contains the requested string then make it 
// foreground and and stop enumeration.
// Return true to continue search, false to stop.
// Arguments: 
//- HWND hw is the enumerated window handle.
//- LPARAM lp is char* string to find in title.
// .......................................................................
BOOL CALLBACK EnumProc(HWND hw, LPARAM lp)
{
    TCHAR name[200];

    //if (IsWindow(hw) && GetClassName(hw, name, DIM(name)) != 0)
    if( IsWindowEnabled(hw) )
    {
        GetWindowText(hw, name, DIM(name));
        if( _tcsstr( _tcsupr( name ), (TCHAR*)lp) != 0 )
        {
            wndMatch = hw;
            SetForegroundWindow(hw);
            return false;
        }
    }
    return true;
}   // EnumProc

// ------------------------------- main -----------------------------------
int __cdecl _tmain(int argc, _TCHAR **argv, _TCHAR **envp)
{
    if ( argc < 2 || _tcsicmp( argv[1], _T("-H")) == 0 )
    {
HELPMSG("wintop 2023.05.19\n");
HELPMSG("Make foreground (top and focus) a window whose title contains the given text.\n");
HELPMSG("wintop title repeat. title is case-insensitive title fragment.\n");
HELPMSG("Optional repeat is number of times to try, default 1 = once.\n");
HELPMSG("This does not work from a command prompt.\n");
        exit(0);
    }
    for( int idx = argc > 2 ? _ttoi(argv[2]) : 1 ; ; )
    {
        EnumWindows(EnumProc, (LPARAM)_tcsupr(argv[1]));
        if (wndMatch != 0 || --idx < 1)
            break;
        Sleep(200);
    }
    return wndMatch == 0 ? 1 : 0 ;
}   // main
