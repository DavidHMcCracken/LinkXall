#!/usr/bin/env python3
# lxainstall/puttools.py Updated 2025.05.04
import os
os.system("dv.py tools+ .py .bat .sh help")
